
public class Movie_Quote {

	public static void main(String[] args) {
		System.out.println("'May the Force be with you' Han Solo, Star Wars, 1977");

	}

}
