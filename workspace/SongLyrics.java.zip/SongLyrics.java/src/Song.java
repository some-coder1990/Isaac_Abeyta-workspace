// Isaac Abeyta, 1/16/24, 24K Magic by Bruno Mars, Brody Brown, Philip Lawrence
public class Song {

	public static void main(String[] args) {
	    System.out.println("Tonight, I just want to take you higher");
	    System.out.println("Throw your hands up in the sky");
	    System.out.println("Let's set this party off right");
	    System.out.println("");
	    System.out.println("Players, put yo' pinky rings up to the moon");
	    System.out.println("Girls, what y'all trying to do");
	    System.out.println("24 karat magic in the air");
	    System.out.println("Head-to-toe, so player");
	    System.out.println("Ah, look out, uh");
	}

}
